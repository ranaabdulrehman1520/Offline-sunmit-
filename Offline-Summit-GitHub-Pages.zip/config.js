window.OFFLINE_CONFIG = {"apiBase":"https://offline-summit-rana.ranaabdulrehman1520.chatgpt.site","basePath":"/Mani-s-QR-code/offline-summit/"};
